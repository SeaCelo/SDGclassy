Training data used in creating an SDG Classifier using an LDA topic model

Full description, instructions and code available in the github: https://github.com/SeaCelo/SDGclassy


Classifier name: "cl_base_new"   (this is the name used in the training and inferring scripts)

Sources:
A) SDG website
B) 3 SG Reports on SG progress (text extracted from each SDG section) -  2016-2018
C) The definition for each targets+indicators (from here: unstats.un.org/sdgs/indicators/indicators-list/)
D) Special Edition of the Sustainable Development Goals Progress Report


Notes:
--A number of preprocessing steps were taken as needed to maximize the ability of the LDA model to differentiate between the SDGs. For example, language describing political and negotiation processes was removed. 

--The model uses Mallet's built-in english stopwords as well as additional stopwords contained in the file "extra-exclude-words_new.txt"

--The confusion matrix was used to determine the quality of this classifier and is included in this collection. 

--This is a work in progress. Kindly share any new data sources or methods used to construct a topic model classifier.



For questions: lafleurm@un.org

